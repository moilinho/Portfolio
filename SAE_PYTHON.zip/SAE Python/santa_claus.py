from time import time
from math import *
from numpy import arccos
from random import *

##############
# SAE S01.01 #
##############

def nb_villes(villes):
    """Retourne le nombre de villes"""
    return len(villes)//3


def noms_villes(villes):
    """Retourne un tableau contenant le nom des villes"""
    noms_v = []
    i = 0
    while 3*i < len(villes):
        noms_v.append(villes[3*i])
        i += 1
    return noms_v


def d2r(nb):
    return nb*pi/180


def distance(long1, lat1, long2, lat2):
    """retourne la distance entre les points (long1, lat1) et (long2, lat2)"""
    lat1 = d2r(lat1)
    long1 = d2r(long1)
    lat2 = d2r(lat2)
    long2 = d2r(long2)
    R = 6370.7
    d = R*arccos(sin(lat1)*sin(lat2)+cos(lat1)*cos(lat2)*cos(long2-long1))
    return d


def indexCity(ville, villes):
    """Retourne l'indice dans le tableau villes de la ville de nom ville,
       et -1 si elle n'existe pas
    """
    res = -1
    i = 0
    while 3*i < len(villes) and villes[3*i] != ville:
        i += 1
    if 3*i < len(villes):
        res = 3*i
    return res


def distance_noms(nom1, nom2, villes):
    """Retourne la distance entre les villes nom1 et nom2 
       en fonction de la structure de données villes
    """
    index1 = indexCity(nom1, villes)
    index2 = indexCity(nom2, villes)

    if index1 == -1 or index2 == -1:
        d = -1
    else:
        d = distance(villes[index1+1], villes[index1+2],
                     villes[index2+1], villes[index2+2])
    return d


def lecture_villes(path):
    """Retourne la structure de données villes en fonction des données du fichier path"""
    f_in = open(path, encoding='utf-8', mode='r')
    villes = []
    li = f_in.readline()
    li = li.strip()
    while li != '':
        tab_li = li.split(';')
        villes.append(tab_li[0])
        villes.append(float(tab_li[1]))
        villes.append(float(tab_li[2]))
        li = f_in.readline()
        li = li.strip()
    f_in.close()
    return villes


def long_tour(villes, tournee):
    """Retourne la longueur d'une tournée en fonction de la structure de données villes"""
    long = 0
    i = 0
    while i+1 < len(tournee):
        long += distance_noms(tournee[i], tournee[i+1], villes)
        i += 1
    long += distance_noms(tournee[i], tournee[0], villes)
    return long

##############
# SAE S01.02 #
##############


def dictionary_cities(villes):
    """
    Cette fonction crée un dictionnaire de distances en parcourant la liste des villes deux fois.
    """
    i = 0
    d1 = {}  # Dictionnaire pour contenir toutes les villes
    ville = noms_villes(villes)  # Création d'un tableau avec juste les noms des villes
    while i < len(ville):
        d2 = {}  # Deuxième dictionnaire pour contenir les distances
        j = 0
        while j < len(ville):  # Parcourir une deuxième fois pour avoir une combinaison de deux villes
            if ville[j] != ville[i]:  # Ne pas mettre la même ville
                d2[ville[j]] = distance_noms(ville[i], ville[j], villes)  # Clé: ville qui change, Valeur: distance
            j = j + 1
        d1[ville[i]] = d2  # Ajouter le deuxième dictionnaire comme valeur pour le premier dictionnaire
        i = i + 1
    return d1



def distance_cities(ville1, ville2, dico):
    """
    Récupère la distance entre deux villes à partir d'un dictionnaire.
    
    Arguments:
        ville1 (str): Le nom de la première ville.
        ville2 (str): Le nom de laième ville.
       ico (dict): LeictionnLa entre les deux vil. Si la distance'est pas trouvée, retourne -1    """
    
    # Vérifie si ville1 existe dans les clés du dictionnaire
    if ville1 not in dico.keys():
        return -1
    
    # Récupère le sous-dictionnaire correspondant à la ville1
    nouveau = dico[ville1]
    
    # Parcourt les clés du sous-dictionnaire
    for i in nouveau.keys():
        # Si ville2 est trouvée, retourne la distance correspondante
        if i == ville2:
            return nouveau[i]
    
    # Si la ville2 n'est pas trouvée, retourne -1
    return -1


def tour_length(tour, dico):
    """
    Calcule la distance totale entre les villes d'un tour.

    Prend en paramètres:
    - tour: une liste représentant un tour de villes
    - dico: un dictionnaire contenant les distances entre les villes

    Retourne la distance totale du tour.
    """
    # Initialisation des variables
    i = 0
    somme = 0

    # Boucle pour calculer la distance entre les paires de villes consécutives
    while i < len(tour) - 1:
        # Ajout de la distance entre la ville actuelle et la ville suivante à la somme
        somme = somme + distance_cities(tour[i], tour[i+1], dico)
        i = i + 1

    # Ajout de la distance entre la dernière ville et la première ville à la somme
    somme = somme + distance_cities(tour[len(tour) - 1], tour[0], dico)

    # Renvoi de la distance totale du tour
    return somme


def closest_city(city,cities,dico):
    "Comparer les distances entre city et chaque élément de cities et récupérer la distance la plus petite"
    i=1
    minimum=distance_cities(city,cities[0],dico)# Enregistrer le premier élément comme la distance la plus petite
    indice=0
    while i < len(cities):
        nouvelle=distance_cities(city,cities[i],dico)
        if nouvelle < minimum :# À chaque boucle, on compare la distance avec minimum
            minimum= nouvelle# Si minimum est plus grand, on fait une affectation pour changer la valeur de minimum
            indice=i
        i=i+1
    return indice
    

def tour_from_closest_city(ville,dico):
    """
    Cette fonction crée une tour en comparant chaque fois la dernière ville ajoutée 
    avec les autres villes pour préciser la distance la plus petite.
    """
    
    tab=[]  # Crée une liste vide pour stocker les villes
    
    for i in dico.keys():  # Parcourt les clés du dictionnaire
        tab.append(i)  # Ajoute chaque clé (représentant une ville) à la liste
    
    nouveau_tab=[]  # Crée une nouvelle liste pour stocker la tour
    
    i=0
    bol = True  # Initialise une variable booléenne à True pour continuer la boucle
    while bol == True:  
        if len(tab) == 1 :
            nouveau_tab.append(tab[0])  # Ajoute la dernière ville à la tour finale
            bol=False  # Sort de la boucle en mettant la variable booléenne à False
        else:
            indice= closest_city(ville,tab,dico)  # Obtiens l'indice de la ville la plus proche
         
            nouveau_tab.append(tab[indice])  # Ajoute la ville la plus proche à la tour
       
            ville=tab[indice]  # Met à jour la variable "ville" avec la nouvelle ville
          
            tab.pop(indice)  # Supprime la ville ajoutée de la liste des villes à comparer
            
    return nouveau_tab  # Retourne la tour finale


def bestour_from_closest(dico):
 """
    Retourne meilleur parcours en des villes les proches.
    """
 # Création de la liste contenant clés du dnaire
    tab = []
    for ville in dico.keys():
        tab.append(ville)
       

    # Initialisation du compteur
    i = 1

    # Appel de la fonction pour créer le premier parcours à partir de la première ville de la liste
    tour = tour_from_closest_city(tab[0], dico)

    # Sauvegarde de la longueur du parcours initial
    minimum = tour_length(tour, dico)
    
    # Parcours des autres villes de la liste
    while i < len(tab):
        # Création d'un nouveau parcours à partir de la ville courante
        verif_tour = tour_from_closest_city(tab[i], dico)
        
        # Vérification si le nouveau parcours est plus court que le parcours actuel
        if tour_length(verif_tour, dico) < minimum:
            # Mise à jour de la longueur minimale et du meilleur parcours
            minimum = tour_length(verif_tour, dico)
            tour = verif_tour

        # Passage à la ville suivante
        i += 1
    
    # Retour du meilleur parcours
    return tour


def reverse_part_tour(tour,ind_b,ind_e):
    """
    Inverse les éléments d'une partie du tableau `tour` entre les indices `ind_b` et `ind_e`.

    """
    if ind_b > ind_e:
        # Si l'indice de début est supérieur à l'indice de fin, on les échange
        tmp=ind_b
        ind_b=ind_e
        ind_e=tmp
    while ind_b <= ind_e:
        tmp=tour[ind_e]  # Sauvegarde de l'élément d'indice `ind_e`
        tour[ind_e]=tour[ind_b]  # Remplacement de la valeur d'indice `ind_e` par celle d'indice `ind_b`
        tour[ind_b]=tmp  # Affectation de la valeur de `ind_e` à `ind_b`
        ind_b=ind_b+1
        ind_e=ind_e-1

def inversion_length_diff(tour, dico, ind_b, ind_e):
    """
    Calcule la différence de longueur entre une tour originale et une tour inversée.

    """

    # Calcul de la longueur du tour original
    dist1 = tour_length(tour, dico)

    # Inversion de la partie du tour indiquée
    reverse_part_tour(tour, ind_b, ind_e)

    # Calcul de la longueur de la tour inversée
    dist2 = tour_length(tour, dico)

    # Calcul de la différence de longueur entre les deux tours
    return dist1 - dist2

def better_inversion_sous_fonction(tour, dico):
    """
    Cherche les indices i et j qui produisent la plus petite modification de distance lorsqu'on inverse deux éléments à ces indices dans la liste tour.
    """
    init_tour = tour  # pour sauvegarder le tour original
    i = 0
    bol = True
    nouveau_tour = []  # sauvegarder le tour qui a la plus petite distance
    fin = []
    while i < len(tour):  # 2 boucles pour essayer toutes les combinaisons possibles d'indices
        j = 0
        while j < len(tour):
            distance = inversion_length_diff(tour, dico, i, j)  # calculer la différence de distance de chaque combinaison d'indices
            if distance > 0 :
                if bol :  # quand la première combinaison "distance > 0" donc il entre une seule fois
                    nouveau_tour = tour  # enregistrer le tour créé
                    minimum = distance  # enregistrer la longueur de tour
                    bol = False
                else:
                    if minimum >= distance :  # si on trouve une longueur de tour plus petite que la longueur minimum
                        minimum = distance  # changer la valeur de minimum par la nouvelle longueur
                        nouveau_tour = tour  # enregistrer le tour
                        nouveau_i = i
                        nouveau_j = j
            j = j + 1
            tour = init_tour.copy()  # changer la valeur de tour à l'original
        i = i + 1
    if bol:  # si elle n'est jamais entrée dans la condition distance > 0
        return [False]
    else:
        return [nouveau_i, nouveau_j]

def better_inversion(tour, dico):
    """
    Effectue une inversion améliorée dans la liste 'tour' en fonction du dictionnaire 'dico'.

    """
    
    tab = better_inversion_sous_fonction(tour, dico)

    if tab[0] != False:
        # Effectue l'inversion dans la liste 'tour' en utilisant les indices 'tab[0]' et 'tab[1]'
        reverse_part_tour(tour, tab[0], tab[1])
        return True
    else:
        return False


def best_obtained_with_inversions(tour, dico):
    """
    Calcule le nombre de fois que l'inversion améliorée peut être effectuée dans la liste 'tour' en fonction du dictionnaire 'dico'.

    """
    
    somme = 0
    verif = better_inversion(tour, dico)

    while verif == True:
        # Effectue l'inversion et vérifie si une autre inversion est possible
        verif = better_inversion(tour, dico)
        somme += 1

    return somme
